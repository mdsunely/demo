import { Component, OnInit, Input } from '@angular/core';
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
HC_exporting(Highcharts);

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {

  @Input() series:any;

  Highcharts: typeof Highcharts = Highcharts;
  pieChartOptions: Highcharts.Options = {
    title: { text: null },
    colorAxis: {},
    plotOptions: {
      pie: {
        allowPointSelect: true,
        cursor: 'pointer',
        dataLabels: {
          enabled: false,
          format: '{point.y}({point.percentage:.1f}%)'
        }
      }
    }
  }

  constructor() { }

  ngOnInit() {}

  ngOnChanges() {
    this.pieChartOptions['series'] = [
      {
        name: '',
        type: 'pie',
        innerSize: '0%',
        data: this.series
      }
    ]
    console.log(this.series);
  }

}
