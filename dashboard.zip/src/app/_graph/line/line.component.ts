import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
HC_exporting(Highcharts);

@Component({
  selector: 'app-line',
  templateUrl: './line.component.html',
  styleUrls: ['./line.component.css']
})
export class LineComponent implements OnInit {
  Highcharts: typeof Highcharts = Highcharts;
  lineChartOptions: Highcharts.Options = {
    title: { text: null },
    xAxis: [{ categories: ['Sep 1st 2020', 'Sep 3rd 2020', 'Sep 5th 2020', 'Sep 7th 2020', 'Sep 13th 2020', 'Sep 15th 2020', 'Sep 19th 2020', 'Sep 23rd 2020', 'Sep 30th 2020'] }],
    yAxis: {
      min: 0,
      title: { text: 'Sales' },
    },
    plotOptions: {
      column: {
        dataLabels: {
          enabled: true
        }
      },
      series: {
        stacking: 'normal'
      },
    },
    series: [
      {
        type: 'line',
        name: 'Kalgoorie',
        data: [250, 0, 120, 300, 150,200, 80, 250,272],
        dataLabels: {
          enabled: true,
          color: '#000000'
        },
      },
      {
        type: 'line',
        name: 'Busselton',
        data: [50, 300, 20, 480, 200,600, 252, 352,72],
        dataLabels: {
          enabled: true,
          color: '#000000'
        },
      },
      {
        type: 'line',
        name: 'Mandurah',
        data: [500, 100, 200, 600, 200,470, 232, 132,152],
        dataLabels: {
          enabled: true,
          color: '#000000'
        },
      }
    ]
  }

  constructor() { }

  ngOnInit() {
  }

}
