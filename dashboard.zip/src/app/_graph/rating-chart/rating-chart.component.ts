import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
HC_exporting(Highcharts);

@Component({
  selector: 'app-rating-chart',
  templateUrl: './rating-chart.component.html',
  styleUrls: ['./rating-chart.component.css']
})
export class RatingChartComponent implements OnInit {
  Highcharts: typeof Highcharts = Highcharts;
  barChartOptions: Highcharts.Options = {
    title: { text: null },
    xAxis: [{ categories: ['5', '4', '3', '2', '1'] }],
    yAxis: {
      min: 0,
      title: { text: '' },
    },
    plotOptions: {
      series: {
        dataLabels: {
          enabled: false,
        },
        stacking: 'normal'
      },
    },
    series: [
      {
        type: 'bar',
        data: [10, 5, 6, 1, 0],
        dataLabels: { enabled: false },
        name: ''
      },
    ]
  }

  constructor() { }

  ngOnInit() {
  }

}
