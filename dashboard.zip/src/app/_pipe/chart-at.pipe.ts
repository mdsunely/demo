import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'charAt'
})
export class ChartAtPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    return value.charAt(0);
  }

}
