import { ChartAtPipe } from './chart-at.pipe';

describe('ChartAtPipe', () => {
  it('create an instance', () => {
    const pipe = new ChartAtPipe();
    expect(pipe).toBeTruthy();
  });
});
