import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {

  appointments = {
    avgStatictics: [
      {title:'No Show',value:'27'},
      {title:'Cancelled',value:'17'},
      {title:'Late',value:'25'},
    ],
    cancelled: [
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
    ],
    noShow: [
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
      {name:'Katelyn Arnold',date:'10/23/20 17:54'},
    ]
  }

  constructor() { }

  ngOnInit() {
  }

}
