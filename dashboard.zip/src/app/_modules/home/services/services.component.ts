import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {

  @Input() data:any;
  title:string = '';
  series:any;

  constructor() { }

  ngOnInit() {}

  ngOnChanges() {
    console.log(this.data)
    this.title = this.data['title'];
    this.series = this.data['data'];
  }

}
