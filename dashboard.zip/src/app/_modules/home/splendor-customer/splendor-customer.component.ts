import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-splendor-customer',
  templateUrl: './splendor-customer.component.html',
  styleUrls: ['./splendor-customer.component.css']
})
export class SplendorCustomerComponent implements OnInit {

  customers:any = [
    {name:'Innaya Dunlop',spent:'$6000', session:'Last 3 days'},
    {name:'Dillon Butt',spent:'$6000', session:'Last 3 days'},
    {name:'Chanelle Cooley',spent:'$6000', session:'Last 3 days'},
    {name:'Ayde Foreman',spent:'$6000', session:'Last 3 days'},
    {name:'Dougie Miles',spent:'$6000', session:'Last 3 days'},
    {name:'Jordanna Cueves',spent:'$6000', session:'Last 3 days'},
    {name:'Shayna Harper',spent:'$6000', session:'Last 3 days'},
    {name:'Katelyn Arnold',spent:'$6000', session:'Last 3 days'},
    {name:'Tim Oconnel',spent:'$6000', session:'Last 3 days'},
    {name:'Maheen Haley',spent:'$6000', session:'Last 3 days'},
    {name:'John Smith',spent:'$6000', session:'Last 3 days'},
    {name:'Richa',spent:'$6000', session:'Last 3 days'},
  ]

  constructor() { }

  ngOnInit() {
  }

}
