import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SplendorCustomerComponent } from './splendor-customer.component';

describe('SplendorCustomerComponent', () => {
  let component: SplendorCustomerComponent;
  let fixture: ComponentFixture<SplendorCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplendorCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplendorCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
