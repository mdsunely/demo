import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.component.html',
  styleUrls: ['./revenue.component.css']
})
export class RevenueComponent implements OnInit {

  revenues:any = [
    {name:'Services',y:60.56},
    {name:'Products',y:43.88},
    {name:'Vouchers',y:8.99},
  ]

  constructor() { }

  ngOnInit() {
  }

}
