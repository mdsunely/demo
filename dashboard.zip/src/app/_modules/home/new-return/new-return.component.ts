import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-return',
  templateUrl: './new-return.component.html',
  styleUrls: ['./new-return.component.css']
})
export class NewReturnComponent implements OnInit {

  customer = {
    title:'New vs Return',
    subTitle:'As of Month Selected',
    data:[
      {title:'Retured', value:'549', percentage:'77%'},
      {title:'New', value:'269', percentage:'33%'}
    ]
  }

  constructor() { }

  ngOnInit() {
  }

}
