import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-average-time',
  templateUrl: './average-time.component.html',
  styleUrls: ['./average-time.component.css']
})
export class AverageTimeComponent implements OnInit {

  waitedTime = {
    text:'Average Waited Time',
    avgWaited:'16 mins',
    customers: [
      {name:'Katelyn Arnold',waited:'30 minutes',ref:'1011542650'},
      {name:'Katelyn Arnold',waited:'45 minutes',ref:'1011542650'},
      {name:'Katelyn Arnold',waited:'27 minutes',ref:'1011542650'},
      {name:'Katelyn Arnold',waited:'18 minutes',ref:'1011542650'},
      {name:'Katelyn Arnold',waited:'9 minutes',ref:'1011542650'},
    ]
  }
  

  constructor() { }

  ngOnInit() {
  }

}
