import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  services = {
    title: 'Services',
    data: [
      { name: 'Relaxation Massage', y: 500 },
      { name: 'Deep Tissue Massage', y: 400 },
      { name: 'Remedial Massage', y: 300 },
      { name: 'Relaxation Massage 2', y: 200 }
    ]
  }

  products = {
    title: 'Products',
    data: [
      { name: 'Relaxation Massage', y: 500 },
      { name: 'Deep Tissue Massage', y: 400 },
      { name: 'Remedial Massage', y: 300 },
      { name: 'Relaxation Massage 2', y: 200 }
    ]
  }

  payments = [
    { name: 'Online', y: 500 },
    { name: 'Banking', y: 400 },
    { name: 'Cash', y: 300 },
    { name: 'Card', y: 200 }
  ]

  businessReviews = {
    title:'Overall Business Rating',
    subTitle:'Service Reviews',
    message: [
      { name: 'Joshua Ramirez', review: "Best massage I've had, second visit and plan on coming back for more", rating: '4' },
      { name: 'Hanna Aquio', review: "Best massage I've had, second visit and plan on coming back for more", rating: '4' },
      { name: 'Angelica Sanchez', review: "Best massage I've had, second visit and plan on coming back for more", rating: '4' }
    ]
  }

  therapistReviews = {
    title:'Therapist Rating',
    subTitle:'Therapist Reviews',
    message: [
      { name: 'Joshua Ramirez', review: "Best massage I've had, second visit and plan on coming back for more", rating: '4' },
      { name: 'Hanna Aquio', review: "Best massage I've had, second visit and plan on coming back for more", rating: '4' },
      { name: 'Angelica Sanchez', review: "Best massage I've had, second visit and plan on coming back for more", rating: '4' }
    ]
  }

  constructor() { }

  ngOnInit() {
  }

}
