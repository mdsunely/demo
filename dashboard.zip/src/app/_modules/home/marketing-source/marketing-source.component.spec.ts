import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketingSourceComponent } from './marketing-source.component';

describe('MarketingSourceComponent', () => {
  let component: MarketingSourceComponent;
  let fixture: ComponentFixture<MarketingSourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketingSourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketingSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
