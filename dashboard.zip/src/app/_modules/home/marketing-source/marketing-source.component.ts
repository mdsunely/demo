import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marketing-source',
  templateUrl: './marketing-source.component.html',
  styleUrls: ['./marketing-source.component.css']
})
export class MarketingSourceComponent implements OnInit {
  sources:any = [
    {name:'Book it App',y:200},
    {name:'Walk In',y:50},
    {name:'Drive In',y:100},
    {name:'Book it App',y:200},
    {name:'Facebook',y:500},
    {name:'Instagram',y:70},
    {name:'Google Map',y:450}
  ]

  constructor() { }

  ngOnInit() {
  }

}
