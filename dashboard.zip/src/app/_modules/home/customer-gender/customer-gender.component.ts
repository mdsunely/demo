import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-gender',
  templateUrl: './customer-gender.component.html',
  styleUrls: ['./customer-gender.component.css']
})
export class CustomerGenderComponent implements OnInit {

  gender = {
      title:'Customer Gender',
      subTitle:'As of Month Selected',
      data:[
        {title:'Male', value:'278', percentage:'53%'},
        {title:'Female', value:'246', percentage:'47%'}
      ]
    }
  

  constructor() { }

  ngOnInit() {
  }

}
