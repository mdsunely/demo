import { Component, OnInit } from '@angular/core';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-range',
  templateUrl: './range.component.html',
  styleUrls: ['./range.component.css','../home.component.css']
})
export class RangeComponent implements OnInit {

  months:any = ['January','Febraury','March','April','May','Jun','July','August','September','October','November','December'];
  years:any = ['2020','2019','2018','2017','2016'];
  viewSelected:string = 'week';

  dropdownList = [
    {item_id:1,item_text:'All'},
    {item_id:2,item_text:'Store - 1'},
    {item_id:3,item_text:'Store - 2'},
    {item_id:4,item_text:'Store - 3'},
    {item_id:5,item_text:'Store - 4'}
  ];
  selectedItems = [{item_id:1,item_text:'All'}];
  dropdownSettings = {
    singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true,
      placeholder:''
  };


  constructor() { }

  ngOnInit() {
  }

}
