import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-drawer',
  templateUrl: './cash-drawer.component.html',
  styleUrls: ['./cash-drawer.component.css']
})
export class CashDrawerComponent implements OnInit {

  constructor() { }

  cashData =  [
    {amt:'$12,345', title:'Kalgoorlie'},
    {amt:'$14,344', title:'Busselton'},
    {amt:'$9,781', title:'Mandurah'}
  ]

  ngOnInit() {
  }

}
