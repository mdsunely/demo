import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-therapist',
  templateUrl: './top-therapist.component.html',
  styleUrls: ['./top-therapist.component.css']
})
export class TopTherapistComponent implements OnInit {
  therapists = [
    {name:'Elyin',reviews:'276', rating:5},
    {name:'James',reviews:'236', rating:5},
    {name:'Erina',reviews:'210', rating:5},
    {name:'John',reviews:'180', rating:5},
    {name:'Kaila',reviews:'178', rating:5},
    {name:'Smith',reviews:'177', rating:5}
  ]

  constructor() { }

  ngOnInit() {
  }

}
