import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-business-rating',
  templateUrl: './business-rating.component.html',
  styleUrls: ['./business-rating.component.css']
})
export class BusinessRatingComponent implements OnInit {

  @Input() data:any;

  reviews:any = [
    
  ]
  constructor() { }

  ngOnInit() {}

  ngOnChanges() {}

}
