import { Component, OnInit, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-left-panel',
  templateUrl: './left-panel.component.html',
  styleUrls: ['./left-panel.component.css']
})
export class LeftPanelComponent implements OnInit {
  @Output() locked = new EventEmitter()
  isLocked:boolean = false


  constructor() { }

  ngOnInit() {
    this.locked.emit(this.isLocked);
  }

  lockedPanel() {
    this.isLocked = !this.isLocked;
    this.locked.emit(this.isLocked);
  }

}
