import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HighchartsChartModule } from 'highcharts-angular';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LeftPanelComponent } from './_layout';
import { HeaderComponent } from './_layout/header/header.component';
import { HomeComponent } from './_modules/home/home.component';
import { RangeComponent } from './_modules/home/range/range.component';
import { CashDrawerComponent } from './_modules/home/cash-drawer/cash-drawer.component';
import { MarketingSourceComponent } from './_modules/home/marketing-source/marketing-source.component';
import { CustomerGenderComponent } from './_modules/home/customer-gender/customer-gender.component';
import { ProgressBarComponent } from './_graph/progress-bar/progress-bar.component';
import { NewReturnComponent } from './_modules/home/new-return/new-return.component';
import { SplendorCustomerComponent } from './_modules/home/splendor-customer/splendor-customer.component';
import { AverageTimeComponent } from './_modules/home/average-time/average-time.component';
import { AppointmentsComponent } from './_modules/home/appointments/appointments.component';
import { RatingComponent } from './_common/rating/rating.component';
import { BusinessRatingComponent } from './_modules/home/business-rating/business-rating.component';
import { ChartAtPipe } from './_pipe/chart-at.pipe';
import { LineComponent } from './_graph/line/line.component';
import { PieChartComponent } from './_graph/pie-chart/pie-chart.component';
import { RevenueComponent } from './_modules/home/revenue/revenue.component';
import { ServicesComponent } from './_modules/home/services/services.component';
import { RatingChartComponent } from './_graph/rating-chart/rating-chart.component';
import { TopTherapistComponent } from './_modules/home/top-therapist/top-therapist.component';

@NgModule({
  declarations: [
    AppComponent,
    LeftPanelComponent,
    HeaderComponent,
    HomeComponent,
    RangeComponent,
    CashDrawerComponent,
    MarketingSourceComponent,
    CustomerGenderComponent,
    ProgressBarComponent,
    NewReturnComponent,
    SplendorCustomerComponent,
    AverageTimeComponent,
    AppointmentsComponent,
    RatingComponent,
    BusinessRatingComponent,
    ChartAtPipe,
    LineComponent,
    PieChartComponent,
    RevenueComponent,
    ServicesComponent,
    RatingChartComponent,
    TopTherapistComponent
  ],
  imports: [
    HighchartsChartModule,
    BrowserModule,
    AppRoutingModule,
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
