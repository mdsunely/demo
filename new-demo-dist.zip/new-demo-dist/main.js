(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/_graph/line-chart/line-chart.component.css":
/*!************************************************************!*\
  !*** ./src/app/_graph/line-chart/line-chart.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL19ncmFwaC9saW5lLWNoYXJ0L2xpbmUtY2hhcnQuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/_graph/line-chart/line-chart.component.html":
/*!*************************************************************!*\
  !*** ./src/app/_graph/line-chart/line-chart.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"chartdiv\" style=\"width: 100%; height: 300px\"></div>"

/***/ }),

/***/ "./src/app/_graph/line-chart/line-chart.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/_graph/line-chart/line-chart.component.ts ***!
  \***********************************************************/
/*! exports provided: LineChartComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LineChartComponent", function() { return LineChartComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @amcharts/amcharts4/core */ "./node_modules/@amcharts/amcharts4/core.js");
/* harmony import */ var _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @amcharts/amcharts4/charts */ "./node_modules/@amcharts/amcharts4/charts.js");
/* harmony import */ var _amcharts_amcharts4_themes_animated__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @amcharts/amcharts4/themes/animated */ "./node_modules/@amcharts/amcharts4/themes/animated.js");






var LineChartComponent = /** @class */ (function () {
    function LineChartComponent(platformId, zone) {
        this.platformId = platformId;
        this.zone = zone;
    }
    // Run the function only in the browser
    LineChartComponent.prototype.browserOnly = function (f) {
        if (Object(_angular_common__WEBPACK_IMPORTED_MODULE_2__["isPlatformBrowser"])(this.platformId)) {
            this.zone.runOutsideAngular(function () {
                f();
            });
        }
    };
    LineChartComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        // Chart code goes in here
        this.browserOnly(function () {
            _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_3__["useTheme"](_amcharts_amcharts4_themes_animated__WEBPACK_IMPORTED_MODULE_5__["default"]);
            var chart = _amcharts_amcharts4_core__WEBPACK_IMPORTED_MODULE_3__["create"]("chartdiv", _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["XYChart"]);
            chart.paddingRight = 20;
            var data = [];
            var visits = 10;
            // for (let i = 1; i < 366; i++) {
            //   visits += Math.round((Math.random() < 0.5 ? 1 : -1) * Math.random() * 10);
            //   data.push({ date: new Date(2018, 0, i), name: "name" + i, value: visits });
            // }
            chart.data = [
                { date: new Date(2019, 5, 12), Kalgoorie: 250, Busselton: 48, Mandurah: 500 },
                { date: new Date(2019, 5, 13), Kalgoorie: 0, Busselton: 300, Mandurah: 200 },
                { date: new Date(2019, 5, 14), Kalgoorie: 120, Busselton: 480, Mandurah: 600 },
                { date: new Date(2019, 5, 15), Kalgoorie: 300, Busselton: 272, Mandurah: 200 },
                { date: new Date(2019, 5, 16), Kalgoorie: 150, Busselton: 144, Mandurah: 400 },
                { date: new Date(2019, 5, 17), Kalgoorie: 200, Busselton: 402, Mandurah: 272 },
                { date: new Date(2019, 5, 18), Kalgoorie: 180, Busselton: 550, Mandurah: 300 }
            ];
            // Create axes
            var dateAxis = chart.xAxes.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["DateAxis"]());
            dateAxis.renderer.minGridDistance = 50;
            var valueAxis = chart.yAxes.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["ValueAxis"]());
            // Create series
            var series = chart.series.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["LineSeries"]());
            series.dataFields.valueY = "Kalgoorie";
            series.dataFields.dateX = "date";
            series.strokeWidth = 2;
            series.minBulletDistance = 10;
            series.tooltipText = "[bold]{date.formatDate()}:[/] {Kalgoorie}}";
            series.tooltip.pointerOrientation = "vertical";
            // Create series
            var series2 = chart.series.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["LineSeries"]());
            series2.dataFields.valueY = "Busselton";
            series2.dataFields.dateX = "date";
            series2.strokeWidth = 2;
            series2.minBulletDistance = 10;
            series2.tooltipText = "[bold]{date.formatDate()}:[/] {Busselton}";
            series2.tooltip.pointerOrientation = "vertical";
            var series3 = chart.series.push(new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["LineSeries"]());
            series3.dataFields.valueY = "Mandurah";
            series3.dataFields.dateX = "date";
            series3.strokeWidth = 2;
            series3.minBulletDistance = 10;
            series3.tooltipText = "[bold]{date.formatDate()}:[/] {Mandurah}";
            series3.tooltip.pointerOrientation = "vertical";
            // Add cursor
            chart.cursor = new _amcharts_amcharts4_charts__WEBPACK_IMPORTED_MODULE_4__["XYCursor"]();
            chart.cursor.xAxis = dateAxis;
            _this.chart = chart;
        });
    };
    LineChartComponent.prototype.ngOnDestroy = function () {
        var _this = this;
        // Clean up chart when the component is removed
        this.browserOnly(function () {
            if (_this.chart) {
                _this.chart.dispose();
            }
        });
    };
    LineChartComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-line-chart',
            template: __webpack_require__(/*! ./line-chart.component.html */ "./src/app/_graph/line-chart/line-chart.component.html"),
            styles: [__webpack_require__(/*! ./line-chart.component.css */ "./src/app/_graph/line-chart/line-chart.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](0, Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_angular_core__WEBPACK_IMPORTED_MODULE_1__["PLATFORM_ID"])),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object, _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"]])
    ], LineChartComponent);
    return LineChartComponent;
}());



/***/ }),

/***/ "./src/app/_layout/left-panel/left-panel.component.css":
/*!*************************************************************!*\
  !*** ./src/app/_layout/left-panel/left-panel.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "header {background-color:#1e2129;height:30px;color:#FFF;padding:8px;}\r\nheader.open {width:250px;}\r\nheader mat-icon {height:30px;width:30px;font-size:30px;float:left;transition:all 0.5s ease; opacity: 0;}\r\nheader.open mat-icon {opacity:1;}\r\nheader h3 {font-size: 16px;float: left;margin-left: 10px;margin-top:4px;transition:all 0.5s ease;font-weight: normal;}\r\nmat-list-item {color:#FFF !important;height:40px !important;}\r\n.hamburger {width:18px;right:0;margin-right: 15px;margin-top:12px;cursor: pointer;position: absolute;z-index:123;top:0;}\r\n.hamburger span {display: block;width: 18px;height: 3px;background-color: #FFF;margin-bottom:3px;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvX2xheW91dC9sZWZ0LXBhbmVsL2xlZnQtcGFuZWwuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxRQUFRLHdCQUF3QixDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO0FBQ3BFLGFBQWEsV0FBVyxDQUFDO0FBQ3pCLGlCQUFpQixXQUFXLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxVQUFVLENBQUMsd0JBQXdCLEVBQUUsVUFBVSxDQUFDO0FBQ3ZHLHNCQUFzQixTQUFTLENBQUM7QUFDaEMsV0FBVyxlQUFlLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQyx3QkFBd0IsQ0FBQyxtQkFBbUIsQ0FBQztBQUNySCxlQUFlLHFCQUFxQixDQUFDLHNCQUFzQixDQUFDO0FBQzVELFlBQVksVUFBVSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDdkgsaUJBQWlCLGNBQWMsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDIiwiZmlsZSI6InNyYy9hcHAvX2xheW91dC9sZWZ0LXBhbmVsL2xlZnQtcGFuZWwuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbImhlYWRlciB7YmFja2dyb3VuZC1jb2xvcjojMWUyMTI5O2hlaWdodDozMHB4O2NvbG9yOiNGRkY7cGFkZGluZzo4cHg7fVxyXG5oZWFkZXIub3BlbiB7d2lkdGg6MjUwcHg7fVxyXG5oZWFkZXIgbWF0LWljb24ge2hlaWdodDozMHB4O3dpZHRoOjMwcHg7Zm9udC1zaXplOjMwcHg7ZmxvYXQ6bGVmdDt0cmFuc2l0aW9uOmFsbCAwLjVzIGVhc2U7IG9wYWNpdHk6IDA7fVxyXG5oZWFkZXIub3BlbiBtYXQtaWNvbiB7b3BhY2l0eToxO31cclxuaGVhZGVyIGgzIHtmb250LXNpemU6IDE2cHg7ZmxvYXQ6IGxlZnQ7bWFyZ2luLWxlZnQ6IDEwcHg7bWFyZ2luLXRvcDo0cHg7dHJhbnNpdGlvbjphbGwgMC41cyBlYXNlO2ZvbnQtd2VpZ2h0OiBub3JtYWw7fVxyXG5tYXQtbGlzdC1pdGVtIHtjb2xvcjojRkZGICFpbXBvcnRhbnQ7aGVpZ2h0OjQwcHggIWltcG9ydGFudDt9XHJcbi5oYW1idXJnZXIge3dpZHRoOjE4cHg7cmlnaHQ6MDttYXJnaW4tcmlnaHQ6IDE1cHg7bWFyZ2luLXRvcDoxMnB4O2N1cnNvcjogcG9pbnRlcjtwb3NpdGlvbjogYWJzb2x1dGU7ei1pbmRleDoxMjM7dG9wOjA7fVxyXG4uaGFtYnVyZ2VyIHNwYW4ge2Rpc3BsYXk6IGJsb2NrO3dpZHRoOiAxOHB4O2hlaWdodDogM3B4O2JhY2tncm91bmQtY29sb3I6ICNGRkY7bWFyZ2luLWJvdHRvbTozcHg7fSJdfQ== */"

/***/ }),

/***/ "./src/app/_layout/left-panel/left-panel.component.html":
/*!**************************************************************!*\
  !*** ./src/app/_layout/left-panel/left-panel.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header [ngClass]=\"{'open':(isExpanded)}\">\n  <mat-icon>account_circle</mat-icon>\n  <h3 *ngIf=\"isExpanded\">Username</h3>\n  <div class=\"hamburger\" (click)=\"toggleSideNav()\">\n    <span></span>\n    <span></span>\n    <span></span>\n  </div>\n</header>\n<mat-list>\n  <mat-list-item *ngFor=\"let nav of navs\">\n    <mat-icon mat-list-icon>{{nav.icon}}</mat-icon>\n    <h4 mat-line *ngIf=\"isExpanded\">{{nav.title}}</h4>\n  </mat-list-item>\n</mat-list>"

/***/ }),

/***/ "./src/app/_layout/left-panel/left-panel.component.ts":
/*!************************************************************!*\
  !*** ./src/app/_layout/left-panel/left-panel.component.ts ***!
  \************************************************************/
/*! exports provided: LeftPanelComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LeftPanelComponent", function() { return LeftPanelComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");



var LeftPanelComponent = /** @class */ (function () {
    function LeftPanelComponent() {
        this.opened = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"];
        this.isExpanded = true;
        this.navs = [
            { title: 'Home', icon: 'home' },
            { title: 'Calendar', icon: 'calendar_today' },
            { title: 'Sales', icon: 'attach_money' },
            { title: 'Client', icon: 'home_repair_service' },
            { title: 'Staff', icon: 'event_seat' },
            { title: 'Services', icon: 'brightness_7' },
            { title: 'Analytiics', icon: 'bar_chart' },
            { title: 'Setup', icon: 'api' },
        ];
    }
    LeftPanelComponent.prototype.ngOnInit = function () { };
    LeftPanelComponent.prototype.toggleSideNav = function () {
        this.isExpanded = !this.isExpanded;
        this.opened.emit(this.isExpanded);
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], LeftPanelComponent.prototype, "opened", void 0);
    LeftPanelComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-left-panel',
            template: __webpack_require__(/*! ./left-panel.component.html */ "./src/app/_layout/left-panel/left-panel.component.html"),
            providers: [_angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSidenav"]],
            styles: [__webpack_require__(/*! ./left-panel.component.css */ "./src/app/_layout/left-panel/left-panel.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], LeftPanelComponent);
    return LeftPanelComponent;
}());



/***/ }),

/***/ "./src/app/_module/home/home.component.css":
/*!*************************************************!*\
  !*** ./src/app/_module/home/home.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL19tb2R1bGUvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/_module/home/home.component.html":
/*!**************************************************!*\
  !*** ./src/app/_module/home/home.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div fxLayout=\"row\" fxLayout.xs=\"column\">\n  <div fxFlex=\"70%\" layout=\"column\" class=\"mat-cloumn\">\n    <app-sales></app-sales>\n  </div>\n  <div fxFlex=\"30%\" layout=\"column\" class=\"mat-cloumn\">\n    <mat-card fxFlex=\"100%;\">\n      <div fxLayout=\"row\" fxLayout.xs=\"column\">\n        test 2\n      </div>\n    </mat-card>\n  </div>\n</div>"

/***/ }),

/***/ "./src/app/_module/home/home.component.ts":
/*!************************************************!*\
  !*** ./src/app/_module/home/home.component.ts ***!
  \************************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var HomeComponent = /** @class */ (function () {
    function HomeComponent() {
    }
    HomeComponent.prototype.ngOnInit = function () {
    };
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/_module/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/_module/home/home.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/_module/home/sales/sales.component.css":
/*!********************************************************!*\
  !*** ./src/app/_module/home/sales/sales.component.css ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL19tb2R1bGUvaG9tZS9zYWxlcy9zYWxlcy5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/_module/home/sales/sales.component.html":
/*!*********************************************************!*\
  !*** ./src/app/_module/home/sales/sales.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-card fxFlex=\"100%;\">\n  <h2>Sales</h2>\n  <div fxLayout=\"row\" fxLayout.xs=\"column\" class=\"row\">\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Location</mat-label>\n        <mat-select multiple class=\"user-control\">\n          <mat-option value=\"{{store.id}}\" *ngFor=\"let store of stores\">{{store.name}}</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>View</mat-label>\n        <mat-select class=\"user-control\" (selectionChange)=\"viewSelectedVal(view.value)\" #view>\n          <mat-option value=\"w\">Weekly</mat-option>\n          <mat-option value=\"m\">Monthly</mat-option>\n          <mat-option value=\"y\">Yearly</mat-option>\n        </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\" *ngIf=\"(viewSelected == 'w')\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Range</mat-label>       \n        <input matInput [matDatepicker]=\"range\">\n        <mat-datepicker-toggle matSuffix [for]=\"range\"></mat-datepicker-toggle>\n        <mat-datepicker #range color=\"primary\"></mat-datepicker>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\" *ngIf=\"(viewSelected == 'm')\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Range</mat-label>       \n          <mat-select class=\"user-control\">\n            <mat-option value=\"{{month}}\" *ngFor=\"let month of months\">{{month}}</mat-option>\n          </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\" *ngIf=\"(viewSelected == 'y')\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Range</mat-label>       \n          <mat-select class=\"user-control\">\n            <mat-option value=\"{{year}}\" *ngFor=\"let year of years\">{{year}}</mat-option>\n          </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\" *ngIf=\"(viewSelected == 'w')\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Compare</mat-label>       \n        <input matInput [matDatepicker]=\"compare\">\n        <mat-datepicker-toggle matSuffix [for]=\"compare\"></mat-datepicker-toggle>\n        <mat-datepicker #compare color=\"primary\"></mat-datepicker>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\" *ngIf=\"(viewSelected == 'm')\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Compare</mat-label>       \n          <mat-select class=\"user-control\">\n            <mat-option value=\"{{month}}\" *ngFor=\"let month of months\">{{month}}</mat-option>\n          </mat-select>\n      </mat-form-field>\n    </div>\n\n    <div fxFlex=\"25%\" fxFlex.xs=\"100%\" layout=\"column\" class=\"mat-cloumn\" *ngIf=\"(viewSelected == 'y')\">\n      <mat-form-field appearance=\"fill\">\n        <mat-label>Compare</mat-label>       \n          <mat-select class=\"user-control\">\n            <mat-option value=\"{{year}}\" *ngFor=\"let year of years\">{{year}}</mat-option>\n          </mat-select>\n      </mat-form-field>\n    </div>\n  </div>\n  <div fxLayout=\"row\" fxLayout.xs=\"column\" class=\"row\">\n    <div fxFlex=\"100%\" layout=\"column\" class=\"mat-cloumn\">\n      <app-line-chart></app-line-chart>\n    </div>\n  </div>\n  \n  \n</mat-card>"

/***/ }),

/***/ "./src/app/_module/home/sales/sales.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/_module/home/sales/sales.component.ts ***!
  \*******************************************************/
/*! exports provided: SalesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesComponent", function() { return SalesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SalesComponent = /** @class */ (function () {
    function SalesComponent() {
        this.months = ['January', 'Febraury', 'March', 'April', 'May', 'Jun', 'July', 'August', 'September', 'October', 'November', 'December'];
        this.years = ['2020', '2019', '2018', '2017', '2016'];
        this.viewSelected = 'w';
        this.stores = [
            { id: 1, name: 'All' },
            { id: 2, name: 'Store - 1' },
            { id: 3, name: 'Store - 2' },
            { id: 4, name: 'Store - 3' },
            { id: 5, name: 'Store - 4' }
        ];
    }
    SalesComponent.prototype.ngOnInit = function () {
    };
    SalesComponent.prototype.viewSelectedVal = function (val) {
        console.log(val);
        this.viewSelected = val;
    };
    SalesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sales',
            template: __webpack_require__(/*! ./sales.component.html */ "./src/app/_module/home/sales/sales.component.html"),
            styles: [__webpack_require__(/*! ./sales.component.css */ "./src/app/_module/home/sales/sales.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SalesComponent);
    return SalesComponent;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _module_home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./_module/home/home.component */ "./src/app/_module/home/home.component.ts");




var routes = [
    { path: '', component: _module_home_home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"] },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".main {height:100vh;}\r\n.leftPanel {background-color:#2d323e;color: #FFF;transition: all 0.5s ease;}\r\n.mainPanel {background-color:#FFF;padding:15px;overflow: auto;transition: all 0.5s ease;display: flex;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxZQUFZLENBQUM7QUFDcEIsWUFBWSx3QkFBd0IsQ0FBQyxXQUFXLENBQUMseUJBQXlCLENBQUM7QUFDM0UsWUFBWSxxQkFBcUIsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLHlCQUF5QixDQUFDLGFBQWEsQ0FBQyIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW4ge2hlaWdodDoxMDB2aDt9XHJcbi5sZWZ0UGFuZWwge2JhY2tncm91bmQtY29sb3I6IzJkMzIzZTtjb2xvcjogI0ZGRjt0cmFuc2l0aW9uOiBhbGwgMC41cyBlYXNlO31cclxuLm1haW5QYW5lbCB7YmFja2dyb3VuZC1jb2xvcjojRkZGO3BhZGRpbmc6MTVweDtvdmVyZmxvdzogYXV0bzt0cmFuc2l0aW9uOiBhbGwgMC41cyBlYXNlO2Rpc3BsYXk6IGZsZXg7fSJdfQ== */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<mat-sidenav-container class=\"main\" autosize>\n  <mat-sidenav #leftPanel  mode=\"side\" opened=\"true\" class=\"leftPanel\">\n    <app-left-panel (opened)=\"toggleSideNav($event)\"></app-left-panel>\n  </mat-sidenav>\n  <div #content class=\"mainPanel\">\n    <router-outlet></router-outlet>\n  </div>\n</mat-sidenav-container>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");



var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.isExpanded = true;
    }
    AppComponent.prototype.toggleSideNav = function (e) {
        console.log(e);
        this.isExpanded = e;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('leftPanel'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material__WEBPACK_IMPORTED_MODULE_2__["MatSidenav"])
    ], AppComponent.prototype, "leftPanel", void 0);
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/flex-layout */ "./node_modules/@angular/flex-layout/esm5/flex-layout.es5.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _layout_left_panel_left_panel_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./_layout/left-panel/left-panel.component */ "./src/app/_layout/left-panel/left-panel.component.ts");
/* harmony import */ var _module_home_home_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./_module/home/home.component */ "./src/app/_module/home/home.component.ts");
/* harmony import */ var _module_home_sales_sales_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./_module/home/sales/sales.component */ "./src/app/_module/home/sales/sales.component.ts");
/* harmony import */ var _graph_line_chart_line_chart_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./_graph/line-chart/line-chart.component */ "./src/app/_graph/line-chart/line-chart.component.ts");













var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"],
                _layout_left_panel_left_panel_component__WEBPACK_IMPORTED_MODULE_8__["LeftPanelComponent"],
                _module_home_home_component__WEBPACK_IMPORTED_MODULE_9__["HomeComponent"],
                _module_home_sales_sales_component__WEBPACK_IMPORTED_MODULE_10__["SalesComponent"],
                _graph_line_chart_line_chart_component__WEBPACK_IMPORTED_MODULE_11__["LineChartComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
                _angular_flex_layout__WEBPACK_IMPORTED_MODULE_3__["FlexLayoutModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_4__["BrowserAnimationsModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatButtonModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatMenuModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSidenavModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatIconModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatListModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatCardModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatFormFieldModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatInputModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatSelectModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatOptionModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatDatepickerModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_5__["MatNativeDateModule"]
            ],
            providers: [],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! F:\dashboard\dashboard\demo\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map